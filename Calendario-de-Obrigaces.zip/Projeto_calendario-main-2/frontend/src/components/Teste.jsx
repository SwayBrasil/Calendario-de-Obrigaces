import React from "react";
const Teste = () => <div style={{ color: "red" }}>Teste de Renderização</div>;
export default Teste;